controls: 
a/d - dolava,doprava
w/space - jump
scroll - camera zoom
exit - esc
mine - lmb
inv - tab