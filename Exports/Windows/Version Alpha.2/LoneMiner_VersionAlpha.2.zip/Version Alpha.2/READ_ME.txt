controls: 
a/d     - dolava,doprava
w/space - jump
scroll  - camera zoom
esc     - exit
lmb     - mine
tab     - inv
h       - show/hide help menu
